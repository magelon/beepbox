#!/bin/bash

mxmlc -target-player=11.1 -source-path=as -static-link-runtime-shared-libraries -output=beepbox-synth/BeepBoxOffline.swf as/MainOffline.mxml;
