#!/bin/bash

mxmlc -target-player=11.1 -debug=true -source-path=as -static-link-runtime-shared-libraries -output=SynthExample.swf as/SynthExample.as;
